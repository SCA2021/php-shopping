<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href='admin_menu.php'>Administrator Login</a>
        <ul>
            <li><a href="index.php">milk</a></li>
            <li><a href="index.php">bread</a></li>
            <li><a href="index.php">eggs</a></li>
            
            <hr/>
            <p>Cart Contents</p>
            <?php
            // TODO: display the cart contents
            ?>
        </ul>
        
    </body>
</html>
