
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="authenticate.php" method="post">
            Username: <input type="text" name="uname"><br>
            Password: <input type="text" name="pwd"><br>
            <input type="submit">
        </form>
    </body>
</html>
